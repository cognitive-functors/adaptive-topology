# FRA Scaling Experiment - Problem Definitions
