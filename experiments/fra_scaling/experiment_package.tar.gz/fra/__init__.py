# FRA (Fingerprint-Route-Adapt) components
